import os
import json
import logging
import pprint
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
iam = boto3.resource('iam')

def detach_policy(role_name, policy_arn):

    """   Detaches a policy from a role.   """
    
    try:
        iam.Role(role_name).detach_policy(PolicyArn=policy_arn)
        logger.info("Detached policy %s from role %s.", policy_arn, role_name)
    except ClientError:
        logger.exception(
            "Couldn't detach policy %s from role %s.", policy_arn, role_name)
        raise

def lambda_handler(event,context):

    role_name = 'AccountAccessRole'
    policy_arn = os.environ['policy_arn']
    detach_policy(role_name, policy_arn)
    print("Detached policy {policy_arn} from {role_name}.")